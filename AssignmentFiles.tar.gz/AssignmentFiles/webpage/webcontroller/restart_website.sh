#!/bin/bash

killall busybox &> /dev/null
tmux new-session -d -s busybox 'busybox httpd -vv -f -p 0.0.0.0:8888 -h `pwd`'
