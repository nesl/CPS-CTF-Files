#! /bin/bash

killall python &> /dev/null
killall roslaunch &> /dev/null
killall busybox &> /dev/null
roslaunch rotors_gazebo mav_with_waypoint_publisher.launch &
cd ~/webpage/webcontroller
tmux new-session -d -s busybox 'busybox httpd -vv -f -p 0.0.0.0:8888 -h `pwd`'
chromium-browser http://127.0.0.1:8888 &
cd ~/Assignment1Files
python ../airTrafficController.pyc
