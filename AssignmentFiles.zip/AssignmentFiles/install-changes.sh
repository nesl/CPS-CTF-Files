#! /bin/bash

cp ./mav_with_waypoint_publisher.launch ~/catkin_ws/src/CrazyS/rotors_gazebo/launch/mav_with_waypoint_publisher.launch
cp ./example_waypoints.txt ~/catkin_ws/src/CrazyS/rotors_gazebo/resource/example_waypoints.txt
cp ./waypoint_publisher_file.cpp ~/catkin_ws/src/CrazyS/rotors_gazebo/src/waypoint_publisher_file.cpp
cp ./route.world ~/catkin_ws/src/CrazyS/rotors_gazebo/worlds/route.world
cp ./airTrafficController.pyc ~/
cp -r Assignment1Files ~/Assignment1Files
cp -r Assignment2Files ~/Assignment2Files
cp -r webpage ~/webpage
cd ~/catkin_ws
catkin build
cd ~/

